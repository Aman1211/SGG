 <div class="col-md-3 product-men single">
								<div class="men-pro-item simpleCart_shelfItem">
									<div class="men-thumb-item">
										<img src="image/<?php echo $i_path;?>" alt="" class="pro-image-front" style="width:220px;height: 220px">
										<img src="image/<?php echo $i_path;?>" alt="" class="pro-image-back">
											<div class="men-cart-pro">
												<div class="inner-men-cart-pro">
													<a href="single.php?id=<?php echo $p_id_r;?>" class="link-product-add-cart">Quick View</a>
												</div>
											</div>
											<span class="product-new-top">New</span>
											
									</div>
									<div class="item-info-product ">
										<h4><a href="single.html?id=<?php echo $p_id_r;?>"><?php echo $p_name;?></a></h4>
										<div class="info-product-price">
											<span>PER SQ.FEET</span><span class="item_price"><?php echo $price_rand;?></span>
											<span><?php echo $mm_name;?></span>				
										</div>
									</div>
								</div>
							</div>