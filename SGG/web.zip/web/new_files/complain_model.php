 <div class="modal fade" id="hp" role="dialog">
    						<div class="modal-dialog">
   						    <!-- Modal content-->
	 						    <div class="modal-content">
		        					<div class="modal-header">
			          					<button type="button" class="close" data-dismiss="modal">&times;</button>
								          <h4 class="modal-title" style="font-size: 30PX;">COMPALIAN</h4>
							        </div>
							        <div class="modal-body">
								        <form>
									        <tr>
									        	<td><label for="PRODUCT NAME">PRODUCT NAME</label><td>
									            <td><select class="form-control"><option class="form-control">1</option><option>1</option><option>1</option><option>1</option></select></td>
									        </tr>
									        <tr>
									        	<td><label for="PRODUCT NAME">Description</label><td><br/>
									            <td><textarea class="form-control" rows="4" cols="50"></textarea></td>
									        </tr>
									        <tr>
									        	<input type="submit" name="submit" id="submit" value="submit" class="btn btn-info btn-block"/>
									            <input type="submit" name="reset" id="reset" value="RESET" class="btn btn-info btn-block"/>
									        </tr>
								        </form>
							    	</div>
							        <div class="modal-footer">
							          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							        </div>
	      						</div>
      
    						</div>
  						</div>