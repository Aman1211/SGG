<?php?>
<!DOCTYPE html>
<html>
<head>
	<title>REQUEST..</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/boostrap/3.3.6/css/bootstrap.min.js">
	<script src="https://maxdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	</script>
	<style>
	.popover{
		width:100%;max-width: 800px;
	}
</style>
</head>
<body>

</body>
</html>