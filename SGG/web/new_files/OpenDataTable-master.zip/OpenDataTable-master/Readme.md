# Open DataTable jQuery plug-in 

Open DataTable is a JQuery plug-in. It is fast, very much realiable, easy to implement, highly flexible and comes with a very beautiful UI.
It is currently avaiblable only with PHP MySQL data source and under development for supporting other data sources in near future.

## Support

Support for Open DataTable is available through email opendatatable@gmail.com

## Documentation
For Documentation and exmaple refer 
[Open DataTable web-site](http://opendatatable.com).

