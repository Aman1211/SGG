<html>
<head>
<title>My first php website</title>
<style>
	body{ 
background-color:#FFFF00;}
</style>
</head>
<body>
<p> <h3>Welcome</h3> </p>
<a href="login2.php"><b>Click here for Login</b></a>
<a href="reg.php"><b>Click here for Registration</b></a>
</body>
</html>
