<?php
$server="localhost";
$username="root";
$password="";
$dbname="first";
$conn=mysqli_connect($server,$username,$password,$dbname);
?>