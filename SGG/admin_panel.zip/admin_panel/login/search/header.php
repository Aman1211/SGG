<?php
include 'conn.php';
?>
<html>
<head>
<title></title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
</html>
