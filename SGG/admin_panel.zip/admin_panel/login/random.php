<?php
$otp=rand(100000,999999);
?>