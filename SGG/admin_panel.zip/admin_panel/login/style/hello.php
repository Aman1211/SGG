<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,intial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="style.css" rel="stylesheet">
<style>
body{
	background:url("container.jpg");
	background-repeat:no-repeat;
	width:100%;
	height:100%vh;
}
</style>
</head>
<body>
<div id="container">
<div id="header">
<img id="logo" src="sgg.jpg"/>
<img id="banner" src="gif.gif"/>
</div>
<div id="menu">
<ul>
<li><a href="#">Home</a></li>
<li><a href="#">Gallery</a></li>
<li><a href="#">About us</a></li>
<li><a href="#">Profile</a></li>
<ul>
</div>
<div id="menu2">
<div class="search">
 <form action="hello.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
</div>
<div class="log">
<ul>
<li><a href="#">Sign in</li></a>
<li><a href="#">Sign up</li></a>
</ul>
</div>
</div>
<div id="sidebar"></div>
<div id="mainbody"></div>
<div id="footer"></div>
</div>
</div>
<div class="col-md-12 col-sm-12 col-xs-12">
</div>
</div>
</div>
</body>
</html>

