<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,intial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<link href="style.css" rel="stylesheet">
<style>
body{
	background:url("container.jpg");
	background-repeat:no-repeat;
	width:100%;
	height:100vh;
}
</style>
</head>
<body>
<div class="container-fluid bg">
<div class="row">
<div class="col-md-4 col-sm-4 col-xs-12"></div>
<div class="col-md-4 col-sm-4 col-xs-12">
<div id="container">
<div id="header">
<img id="logo" src="sgg.jpg"/>
<img id="banner" src="gif.gif"/>
</div>
<div id="menu">
<ul>
<li><a href="#">Home</a></li>
<li><a href="#">Gallery</a></li>
<li><a href="#">About us</a></li>
<li><a href="#">Profile</a></li>
<ul>
</div>
<div id="menu2">
<div class="search">
 <form action="home.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
</div>
<div class="log">
<ul>
<li><a href="#">Sign in</li></a>
<li><a href="#">Sign up</li></a>
</ul>
</div>
</div>
<div id="sidebar"></div>
<div id="mainbody"></div>
<div id="footer"></div>
</div>
</div>
<div class="col-md-4 col-sm-4 col-xs-12">
</div>
</div>
</div>
</body>
</html>

