<html>
<head>
<style>
body{
	background-color:#f4f5;
</style>
<title>
	Customer Page
</title>
</head>
<body>
<h2><b>This is a Customer Page </b></h2>
</body>
</html>
